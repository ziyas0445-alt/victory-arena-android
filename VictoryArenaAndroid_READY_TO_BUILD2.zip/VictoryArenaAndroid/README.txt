Victory Arena Android WebView project

This project wraps your supplied Victory Arena HTML app in a native Android WebView.

To build the APK:
1. Install Android Studio on a computer.
2. Open this folder (VictoryArenaAndroid) in Android Studio.
3. Let Gradle sync finish and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at app/build/outputs/apk/debug/app-debug.apk

Important:
- This environment does not have Android SDK / Gradle installed, so an APK could not be compiled here.
- The HTML app uses external CDN/font/image services and requires internet access for those resources.
- Test login, Firebase, payment, QR and notification flows on a real phone before public release.
- This is a debug APK build setup; create a signed release APK in Android Studio before distributing publicly.
